from flask import Flask, render_template, jsonify, request, redirect, url_for
import sqlite3
import json
from datetime import datetime
import os
import requests

app = Flask(__name__)

# Настройки
TELEGRAM_TOKEN = "7824059826:AAEQx8WETTaAE4iU-tC58fT9ODkotjo-Enc"
NOTIFICATION_CHAT_ID = 1623256768
WORK_LATITUDE = 55.676803
WORK_LONGITUDE = 37.52351
WORK_RADIUS = 100  # метров

def init_db():
    """Инициализация базы данных"""
    conn = sqlite3.connect('driver.db')
    c = conn.cursor()
    
    # Таблица отслеживания
    c.execute('CREATE TABLE IF NOT EXISTS tracking (id INTEGER PRIMARY KEY, active BOOLEAN DEFAULT 0)')
    c.execute('INSERT OR IGNORE INTO tracking (id, active) VALUES (1, 0)')
    
    # Таблица последнего местоположения
    c.execute('''CREATE TABLE IF NOT EXISTS last_location 
                 (id INTEGER PRIMARY KEY, latitude REAL, longitude REAL, timestamp TEXT)''')
    
    conn.commit()
    conn.close()

def get_tracking_status():
    """Получить статус отслеживания"""
    conn = sqlite3.connect('driver.db')
    c = conn.cursor()
    c.execute('SELECT active FROM tracking WHERE id = 1')
    result = c.fetchone()
    conn.close()
    return bool(result[0]) if result else False

def set_tracking_status(active):
    """Установить статус отслеживания"""
    conn = sqlite3.connect('driver.db')
    c = conn.cursor()
    c.execute('UPDATE tracking SET active = ? WHERE id = 1', (1 if active else 0,))
    conn.commit()
    conn.close()

def save_location(lat, lon):
    """Сохранить местоположение"""
    conn = sqlite3.connect('driver.db')
    c = conn.cursor()
    c.execute('DELETE FROM last_location WHERE id = 1')
    c.execute('INSERT INTO last_location (id, latitude, longitude, timestamp) VALUES (1, ?, ?, ?)',
              (lat, lon, datetime.now().isoformat()))
    conn.commit()
    conn.close()

def get_last_location():
    """Получить последнее местоположение"""
    conn = sqlite3.connect('driver.db')
    c = conn.cursor()
    c.execute('SELECT latitude, longitude, timestamp FROM last_location WHERE id = 1')
    result = c.fetchone()
    conn.close()
    return result if result else (None, None, None)

def calculate_distance(lat1, lon1, lat2, lon2):
    """Рассчитать расстояние между точками"""
    import math
    R = 6371000  # Радиус Земли в метрах
    lat1_rad, lat2_rad = math.radians(lat1), math.radians(lat2)
    delta_lat, delta_lon = math.radians(lat2-lat1), math.radians(lon2-lon1)
    a = math.sin(delta_lat/2)**2 + math.cos(lat1_rad)*math.cos(lat2_rad)*math.sin(delta_lon/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))

def is_at_work(lat, lon):
    """Проверить, находится ли водитель на работе"""
    if lat is None or lon is None:
        return False
    return calculate_distance(lat, lon, WORK_LATITUDE, WORK_LONGITUDE) <= WORK_RADIUS

def send_telegram_notification():
    """Отправить уведомление через Telegram"""
    current_hour = datetime.now().hour
    if 5 <= current_hour < 12:
        greeting = "Доброе утро"
    elif 12 <= current_hour < 18:
        greeting = "Добрый день"
    elif 18 <= current_hour < 23:
        greeting = "Добрый вечер"
    else:
        greeting = "Доброй ночи"
    
    message = f"{greeting}! У подъезда, ожидаю"
    
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    data = {
        "chat_id": NOTIFICATION_CHAT_ID,
        "text": message
    }
    
    try:
        response = requests.post(url, json=data)
        if response.status_code == 200:
            return True, "Уведомление отправлено"
        else:
            return False, f"Ошибка API: {response.status_code}"
    except Exception as e:
        return False, f"Ошибка отправки: {str(e)}"

@app.route('/')
def index():
    """Главная страница"""
    tracking = get_tracking_status()
    lat, lon, timestamp = get_last_location()
    
    status = "📍 На работе" if is_at_work(lat, lon) else "🚗 В пути"
    distance = calculate_distance(lat or 0, lon or 0, WORK_LATITUDE, WORK_LONGITUDE) if lat and lon else 0
    distance_text = f"{int(distance)} м" if distance < 1000 else f"{distance/1000:.1f} км"
    
    return render_template('index_simple.html', 
                         tracking=tracking,
                         status=status,
                         latitude=lat,
                         longitude=lon,
                         distance=distance_text,
                         timestamp=timestamp,
                         work_lat=WORK_LATITUDE,
                         work_lon=WORK_LONGITUDE)

@app.route('/api/status')
def api_status():
    """API статуса"""
    tracking = get_tracking_status()
    lat, lon, timestamp = get_last_location()
    
    status = "at_work" if is_at_work(lat, lon) else "on_way"
    distance = calculate_distance(lat or 0, lon or 0, WORK_LATITUDE, WORK_LONGITUDE) if lat and lon else 0
    
    return jsonify({
        'tracking': tracking,
        'status': status,
        'latitude': lat,
        'longitude': lon,
        'distance': int(distance),
        'timestamp': timestamp,
        'work_latitude': WORK_LATITUDE,
        'work_longitude': WORK_LONGITUDE
    })

@app.route('/api/tracking/toggle', methods=['POST'])
def toggle_tracking():
    """Переключить отслеживание"""
    current = get_tracking_status()
    set_tracking_status(not current)
    return redirect(url_for('index'))

@app.route('/api/location', methods=['POST'])
def update_location():
    """Обновить местоположение"""
    data = request.get_json()
    lat = data.get('latitude')
    lon = data.get('longitude')
    
    if lat and lon:
        save_location(lat, lon)
        return jsonify({'success': True})
    
    return jsonify({'success': False, 'error': 'Invalid coordinates'})

@app.route('/api/notify', methods=['POST'])
def send_notification():
    """Отправить уведомление"""
    success, message = send_telegram_notification()
    return jsonify({'success': success, 'message': message})

if __name__ == '__main__':
    # Инициализируем базу данных
    init_db()
    
    print("🌐 Запуск упрощенного веб-интерфейса...")
    print("📍 Адрес: http://0.0.0.0:5000")
    print(f"📱 Уведомления отправляются в чат: {NOTIFICATION_CHAT_ID}")
    
    app.run(host='0.0.0.0', port=5000, debug=True) 